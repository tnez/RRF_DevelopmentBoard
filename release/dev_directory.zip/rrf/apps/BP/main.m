//
//  main.m
//  BP
//
//  Created by Travis Nesland on 8/3/10.
//  Copyright University of Kentucky 2010. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
