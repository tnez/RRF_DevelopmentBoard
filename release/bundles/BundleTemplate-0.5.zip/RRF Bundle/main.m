////////////////////////////////////////////////////////////
//  main.m
//  MockApplication (used for bundle testing)
//  --------------------------------------------------------
//  Author: Travis Nesland <tnesland@gmail.com>
//  Created: 9/5/10
//  Copyright 2010 Residential Research Facility,
//  University of Kentucky. All rights reserved.
/////////////////////////////////////////////////////////////

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
